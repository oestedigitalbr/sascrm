<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\KnowledgeBase;
use Ramsey\Uuid\Uuid;

class KnowledgeBaseController {

    /**
     * GET /api/knowledge-bases
     * Lista todos os formulários e decodifica o JSON das perguntas.
     */
    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        
        $bases = KnowledgeBase::where('user_id', $userToken->sub)->get();
        
        // Garante que quem vem do banco como string vire JSON real pro React
        $bases = $bases->map(function($base) {
            if (is_string($base->questions)) {
                $base->questions = json_decode($base->questions);
            }
            return $base;
        });

        $response->getBody()->write($bases->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    /**
     * POST /api/knowledge-bases
     * Cria novo formulário. Converte Array -> String JSON antes de salvar.
     */
    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();

        if (empty($data['name'])) {
            $response->getBody()->write(json_encode(['error' => 'Nome é obrigatório']));
            return $response->withStatus(400);
        }

        try {
            // FIX CRÍTICO: Força conversão para string JSON se for array
            $questionsPayload = isset($data['questions']) && is_array($data['questions']) 
                ? json_encode($data['questions'], JSON_UNESCAPED_UNICODE) 
                : '[]';

            $kb = KnowledgeBase::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'name' => $data['name'],
                'questions' => $questionsPayload
            ]);

            // Decodifica de volta pra responder pro front bonito
            $kb->questions = json_decode($kb->questions);

            $response->getBody()->write($kb->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode([
                'error' => 'Erro ao salvar base',
                'details' => $e->getMessage()
            ]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    /**
     * PUT /api/knowledge-bases/{id}
     * Atualiza formulário existente.
     */
    public function update(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();
        $id = $args['id'];

        $kb = KnowledgeBase::where('id', $id)->where('user_id', $userToken->sub)->first();

        if (!$kb) {
            return $response->withStatus(404);
        }

        try {
            if (isset($data['name'])) $kb->name = $data['name'];
            
            // Tratamento manual do JSON igual no Store
            if (isset($data['questions'])) {
                $questionsPayload = is_array($data['questions']) 
                    ? json_encode($data['questions'], JSON_UNESCAPED_UNICODE) 
                    : $data['questions'];
                $kb->questions = $questionsPayload;
            }

            $kb->save();

            // Decodifica pra devolver bonito
            $kb->questions = is_string($kb->questions) ? json_decode($kb->questions) : $kb->questions;

            $response->getBody()->write($kb->toJson());
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500);
        }
    }

    /**
     * DELETE /api/knowledge-bases/{id}
     * Remove formulário.
     */
    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $kb = KnowledgeBase::where('id', $args['id'])->where('user_id', $userToken->sub)->first();

        if ($kb) {
            $kb->delete();
            $response->getBody()->write(json_encode(['message' => 'Deletado com sucesso']));
        } else {
            return $response->withStatus(404);
        }
        return $response->withHeader('Content-Type', 'application/json');
    }
}