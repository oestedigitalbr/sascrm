<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Lead extends Model {
    protected $table = 'leads';
    
    // AQUI ESTÁ A CHAVE: Adicionei 'pipeline', 'agent_paused', etc.
    protected $fillable = [
        'id', 
        'user_id', 
        'name', 
        'phone', 
        'email', 
        'value', 
        'status', 
        'pipeline',       // <--- Novo
        'agent_paused',   // <--- Novo
        'follow_up_date', // <--- Novo
        'follow_up_notes' // <--- Novo
    ];
    
    public $incrementing = false;
    protected $keyType = 'string';

    protected $casts = [
        'value' => 'float',
        'agent_paused' => 'boolean'
    ];
}