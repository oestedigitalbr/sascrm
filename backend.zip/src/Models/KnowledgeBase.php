<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class KnowledgeBase extends Model {
    protected $table = 'knowledge_bases';
    protected $fillable = ['id', 'user_id', 'name', 'questions'];
    public $incrementing = false;
    protected $keyType = 'string';

    // A MÁGICA ACONTECE AQUI:
    protected $casts = [
        'questions' => 'array', // O Eloquent converte auto p/ JSON ao salvar e Array ao ler
    ];
}