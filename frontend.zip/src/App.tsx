import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Products from './pages/Products';
import CRM from './pages/CRM';
import Agents from './pages/Agents';
import Connections from './pages/Connections'; // <--- Nova Importação
import Intelligence from './pages/Intelligence'; // <--- Nova Importação
import Layout from './components/Layout';

// Dashboard Placeholder (Visão Geral)
function DashboardHome() {
  return (
    <Layout title="Visão Geral">
       <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
         <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg animate-fade-in-up">
           <h3 className="text-slate-400 text-sm font-medium">Leads Ativos</h3>
           <p className="text-3xl font-bold text-white mt-2">124</p>
         </div>
         <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg animate-fade-in-up delay-100">
           <h3 className="text-slate-400 text-sm font-medium">Vendas Hoje</h3>
           <p className="text-3xl font-bold text-emerald-400 mt-2">R$ 4.250,00</p>
         </div>
         <div className="bg-slate-900 p-6 rounded-2xl border border-slate-800 shadow-lg animate-fade-in-up delay-200">
           <h3 className="text-slate-400 text-sm font-medium">Conversões IA</h3>
           <p className="text-3xl font-bold text-purple-400 mt-2">18%</p>
         </div>
       </div>
    </Layout>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />
        
        {/* === ROTAS DO SISTEMA (Todas Protegidas) === */}
        <Route path="/dashboard" element={<DashboardHome />} />
        <Route path="/crm" element={<CRM />} />
        <Route path="/products" element={<Products />} />
        
        {/* Rotas Avançadas */}
        <Route path="/agents" element={<Agents />} />
        <Route path="/intelligence" element={<Intelligence />} /> {/* <--- Rota Nova */}
        <Route path="/connections" element={<Connections />} />   {/* <--- Rota Nova */}

        {/* Placeholder para Agenda */}
        <Route path="/agenda" element={<Layout title="Agenda"><p className="text-slate-500">Agenda integrada em breve...</p></Layout>} />

        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App