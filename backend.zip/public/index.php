<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Illuminate\Database\Capsule\Manager as Capsule;
use Slim\Routing\RouteCollectorProxy;

require __DIR__ . '/../vendor/autoload.php';

// Carrega variáveis de ambiente
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__ . '/..');
$dotenv->load();

// Configura o Eloquent (Banco de Dados)
$capsule = new Capsule;
$capsule->addConnection([
    'driver'    => $_ENV['DB_DRIVER'],
    'host'      => $_ENV['DB_HOST'],
    'database'  => $_ENV['DB_DATABASE'],
    'username'  => $_ENV['DB_USERNAME'],
    'password'  => $_ENV['DB_PASSWORD'],
    'charset'   => 'utf8',
    'collation' => 'utf8_unicode_ci',
    'prefix'    => '',
]);
$capsule->setAsGlobal();
$capsule->bootEloquent();

// Inicializa o App Slim
$app = AppFactory::create();

// === CORS (Permitir que o React converse com o PHP) ===
$app->options('/{routes:.+}', function ($request, $response, $args) {
    return $response;
});

$app->add(function ($request, $handler) {
    $response = $handler->handle($request);
    return $response
            ->withHeader('Access-Control-Allow-Origin', '*') // Em produção, troque '*' pelo domínio do seu site
            ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
            ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
});

// 1. Middleware para interpretar JSON
$app->addBodyParsingMiddleware();

// 2. Middleware de Roteamento (Essencial)
$app->addRoutingMiddleware();

// 3. Middleware de Erros (Mostra JSON ao invés de tela branca)
$errorMiddleware = $app->addErrorMiddleware(true, true, true);

// === ROTAS ===
// Rota de Automação (Geralmente chamada por um Cron Job do servidor)
$app->get('/cron/followups', \App\Controllers\AutomationController::class . ':checkFollowUps');


// Rota de Teste (Health Check)
$app->get('/', function (Request $request, Response $response) {
    $payload = json_encode(['status' => 'AgenteUP4 API Online 🚀', 'version' => '1.2']);
    $response->getBody()->write($payload);
    return $response->withHeader('Content-Type', 'application/json');
});

// === ROTAS DE AUTENTICAÇÃO (Públicas) ===
// Atenção: Verifique se estas linhas aparecem APENAS UMA VEZ no arquivo
$app->post('/auth/register', \App\Controllers\AuthController::class . ':register');
$app->post('/auth/login', \App\Controllers\AuthController::class . ':login');

// === ROTAS PROTEGIDAS (Precisam de Token) ===
$app->group('/api', function (RouteCollectorProxy $group) {
    

   // Rotas de Inteligência
    $group->get('/knowledge-bases', \App\Controllers\KnowledgeBaseController::class . ':index');
    $group->post('/knowledge-bases', \App\Controllers\KnowledgeBaseController::class . ':store');
    // NOVAS:
    $group->put('/knowledge-bases/{id}', \App\Controllers\KnowledgeBaseController::class . ':update');
    $group->delete('/knowledge-bases/{id}', \App\Controllers\KnowledgeBaseController::class . ':destroy');

    
    // Rotas WhatsApp (Meta API)
    $group->get('/whatsapp', \App\Controllers\WhatsAppController::class . ':index');
    $group->post('/whatsapp', \App\Controllers\WhatsAppController::class . ':store');
    $group->delete('/whatsapp/{id}', \App\Controllers\WhatsAppController::class . ':destroy');

  // Rotas de Agentes (Multi-Agentes)
    $group->get('/agents', \App\Controllers\AgentController::class . ':index');
    $group->post('/agents', \App\Controllers\AgentController::class . ':store');
    $group->put('/agents/{id}', \App\Controllers\AgentController::class . ':update');
    $group->delete('/agents/{id}', \App\Controllers\AgentController::class . ':destroy');

    // Produtos
    $group->get('/products', \App\Controllers\ProductController::class . ':index');
    $group->post('/products', \App\Controllers\ProductController::class . ':store');

    // Rota para Atualizar (POST por causa da imagem)
    $group->post('/products/{id}', \App\Controllers\ProductController::class . ':update');
    
    // Rota para Deletar
    $group->delete('/products/{id}', \App\Controllers\ProductController::class . ':destroy');

    // IA Generativa
    $group->post('/ai/generate', \App\Controllers\AIController::class . ':generate');

    // === CRM & LEADS ===
    $group->get('/crm/board', \App\Controllers\CRMController::class . ':index'); // Busca tudo
    $group->post('/crm/leads', \App\Controllers\CRMController::class . ':store'); // Cria Lead
    $group->put('/crm/leads/{id}/move', \App\Controllers\CRMController::class . ':move'); // Move Card
    $group->delete('/crm/leads/{id}', \App\Controllers\CRMController::class . ':destroy'); // Apaga Lead
    $group->put('/crm/leads/{id}', \App\Controllers\CRMController::class . ':update');
    
})->add(new \App\Middleware\AuthMiddleware());

$app->run();