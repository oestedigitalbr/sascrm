<?php
namespace App\Controllers;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Appointment;
use Ramsey\Uuid\Uuid;

class AgendaController {
    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        // Traz as reuniões e os dados do Lead associado
        $appointments = Appointment::with('lead')->where('user_id', $userToken->sub)->orderBy('start_time', 'asc')->get();
        $response->getBody()->write($appointments->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();
        try {
            $apt = Appointment::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'lead_id' => $data['lead_id'],
                'title' => $data['title'],
                'start_time' => $data['start_time'],
                'observations' => $data['observations'] ?? '',
                'status' => 'scheduled'
            ]);
            $response->getBody()->write($apt->toJson());
            return $response->withStatus(201);
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500);
        }
    }
}