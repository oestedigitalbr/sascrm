import { useEffect, useState } from 'react';
import Layout from '../components/Layout';
import api from '../services/api';
import CreateAgentModal from '../components/CreateAgentModal';
import { Bot, Plus, Power, MessageSquare, Trash2, Brain, Edit } from 'lucide-react'; // Importe Edit

interface Agent {
  id: string;
  name: string;
  role: string;
  is_active: boolean;
  whatsapp?: { name: string; };
  whatsapp_instance_id?: string; // Importante para o modal saber qual selecionar
  knowledge_base_id?: string;    // Importante para o modal saber qual selecionar
}

export default function Agents() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Controle do Modal
  const [isWizardOpen, setIsWizardOpen] = useState(false);
  const [editingAgent, setEditingAgent] = useState<Agent | undefined>(undefined); // Estado para o agente sendo editado

  async function loadAgents() {
    try {
      const response = await api.get('/api/agents');
      setAgents(response.data);
    } catch (error) {
      console.error("Erro ao carregar agentes", error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadAgents(); }, []);

  async function toggleActive(agent: Agent) {
      try {
          const updatedAgents = agents.map(a => a.id === agent.id ? {...a, is_active: !a.is_active} : a);
          setAgents(updatedAgents);
          await api.put(`/api/agents/${agent.id}`, { is_active: !agent.is_active });
      } catch (error) {
          loadAgents();
          alert('Erro ao alterar status');
      }
  }

  async function handleDelete(id: string) {
      if(!confirm('Tem certeza que deseja excluir este agente?')) return;
      try {
          await api.delete(`/api/agents/${id}`);
          setAgents(agents.filter(a => a.id !== id));
      } catch (error) {
          alert('Erro ao excluir agente');
      }
  }

  // --- FUNÇÕES DE ABERTURA DO MODAL ---

  function handleCreate() {
      setEditingAgent(undefined); // Limpa edição
      setIsWizardOpen(true);
  }

  function handleEdit(agent: Agent) {
      setEditingAgent(agent); // Define quem será editado
      setIsWizardOpen(true);
  }

  return (
    <Layout title="Meus Agentes IA">
      <div className="w-full">
        
        <div className="mb-8 flex justify-between items-center">
            <p className="text-slate-400">Gerencie sua equipe de inteligência artificial.</p>
            <button 
                onClick={handleCreate}
                className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition shadow-lg shadow-blue-900/20"
            >
                <Plus size={18} /> Criar Novo Agente
            </button>
        </div>

        {loading ? (
            <div className="text-center text-slate-500 py-20">Carregando equipe...</div>
        ) : agents.length === 0 ? (
            <div className="text-center py-20 bg-slate-900/50 rounded-2xl border border-slate-800 border-dashed">
                <Bot size={48} className="mx-auto text-slate-600 mb-4"/>
                <h3 className="text-slate-300 font-medium">Você ainda não tem agentes</h3>
                <p className="text-slate-500 text-sm mt-2">Clique em "Criar Novo Agente" para iniciar.</p>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {agents.map(agent => (
                    <div key={agent.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-lg hover:border-slate-700 transition group flex flex-col">
                        
                        <div className="flex justify-between items-start mb-4">
                            <div className="bg-gradient-to-br from-blue-600/20 to-purple-600/20 p-3 rounded-xl border border-white/5">
                                <Bot size={24} className="text-blue-400" />
                            </div>
                            
                            {/* BOTÕES DE AÇÃO DO CARD */}
                            <div className="flex gap-1">
                                <button 
                                    onClick={() => handleEdit(agent)}
                                    className="p-2 text-slate-500 hover:text-white hover:bg-slate-800 rounded-lg transition"
                                    title="Editar"
                                >
                                    <Edit size={16}/>
                                </button>
                                <button 
                                    onClick={() => handleDelete(agent.id)} 
                                    className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-900/20 rounded-lg transition"
                                    title="Excluir"
                                >
                                    <Trash2 size={16}/>
                                </button>
                            </div>
                        </div>

                        <h3 className="text-lg font-bold text-white mb-1">{agent.name}</h3>
                        <p className="text-sm text-slate-400 mb-4">{agent.role}</p>

                        <div className="space-y-2 mb-6 flex-1">
                            <div className="bg-slate-950 rounded-lg p-2 px-3 border border-slate-800 flex items-center gap-2">
                                <MessageSquare size={14} className="text-emerald-500"/>
                                <span className="text-xs text-slate-300 truncate">
                                    {agent.whatsapp ? agent.whatsapp.name : 'Sem WhatsApp'}
                                </span>
                            </div>
                            <div className="bg-slate-950 rounded-lg p-2 px-3 border border-slate-800 flex items-center gap-2">
                                <Brain size={14} className="text-purple-500"/>
                                <span className="text-xs text-slate-300 truncate">
                                    {agent.knowledge_base_id ? 'Treinamento Personalizado' : 'Inteligência Genérica'}
                                </span>
                            </div>
                        </div>

                        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                            <span className={`text-xs px-2 py-1 rounded border ${agent.is_active ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-slate-800 border-slate-700 text-slate-500'}`}>
                                {agent.is_active ? 'Ativo' : 'Pausado'}
                            </span>
                            <button 
                                onClick={() => toggleActive(agent)}
                                className={`p-2 rounded-lg transition ${agent.is_active ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30' : 'bg-slate-800 text-slate-500 hover:text-slate-300'}`}
                            >
                                <Power size={18} />
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        )}

        {/* MODAL (Passamos o agentToEdit) */}
        <CreateAgentModal 
            isOpen={isWizardOpen} 
            onClose={() => setIsWizardOpen(false)} 
            onSuccess={loadAgents}
            agentToEdit={editingAgent} // <--- AQUI A MÁGICA
        />
        
      </div>
    </Layout>
  );
}