<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Lead;
use App\Models\Agent;
use App\Services\OpenAIService; // Supondo que você tenha o serviço de IA separado
// Se não tiver serviço separado, a lógica da OpenAI vai aqui dentro

class AutomationController {

    public function checkFollowUps(Request $request, Response $response) {
        // 1. Pega o horário atual
        $now = date('Y-m-d H:i:s');

        // 2. Busca Leads que:
        // - Têm data de follow-up marcada
        // - A data já passou (<= $now)
        // - O Agente NÃO está pausado (se tiver pausado, o humano que cuida)
        $leads = Lead::whereNotNull('follow_up_date')
                     ->where('follow_up_date', '<=', $now)
                     ->where('agent_paused', false) 
                     ->get();

        $processed = [];

        foreach ($leads as $lead) {
            // Verifica se tem nota para guiar o agente
            $instruction = $lead->follow_up_notes ?: "Entre em contato para retomar a conversa.";

            // 3. A MÁGICA: O Agente "Lê" a nota e gera a mensagem
            // Aqui simulamos a chamada para a OpenAI. 
            // Na prática, você chamaria sua função de gerar resposta.
            $aiMessage = $this->generateMessageFromNote($lead->name, $instruction);

            // 4. ENVIA O ZAP (Simulação da chamada da API do WhatsApp)
            // Aqui você chamaria o WhatsAppController ou Service para disparar
            // $whatsAppService->sendMessage($lead->phone, $aiMessage);
            
            // 5. Limpa o Follow-up para não enviar repetido (loop infinito)
            $lead->follow_up_date = null; 
            $lead->follow_up_notes = null; // Ou move para histórico
            $lead->save();

            $processed[] = [
                'lead' => $lead->name,
                'message_generated' => $aiMessage
            ];
        }

        $response->getBody()->write(json_encode([
            'message' => 'Verificação concluída',
            'processed_count' => count($processed),
            'details' => $processed
        ]));
        
        return $response->withHeader('Content-Type', 'application/json');
    }

    // Função auxiliar simples para simular a IA (no real usaria o GPT)
    private function generateMessageFromNote($name, $note) {
        // Exemplo de Prompt interno:
        // "Você é um assistente. O cliente é $name. 
        // Sua missão agora é: $note. 
        // Escreva uma mensagem curta e convidativa para o WhatsApp."
        
        return "Olá $name! Tudo bem? Estou passando aqui pois fiquei de retornar: $note. Podemos conversar?";
    }
}