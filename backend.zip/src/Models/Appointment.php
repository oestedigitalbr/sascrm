<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Appointment extends Model {
    protected $table = 'appointments';
    protected $fillable = ['id', 'user_id', 'lead_id', 'title', 'start_time', 'status', 'observations'];
    public $incrementing = false;
    protected $keyType = 'string';
    
    public function lead() { return $this->belongsTo(Lead::class); }
}