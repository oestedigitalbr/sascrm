<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use GuzzleHttp\Client;

class AIController {

    public function generate(Request $request, Response $response) {
        $user = $request->getAttribute('user'); // Pega quem tá pedindo
        $data = $request->getParsedBody();
        
        $prompt = $data['prompt'] ?? '';
        $context = $data['context'] ?? 'marketing'; // Pode ser 'vendas', 'suporte', etc.

        if (empty($prompt)) {
            $response->getBody()->write(json_encode(['error' => 'O prompt é obrigatório']));
            return $response->withStatus(400);
        }

        // Aqui a gente define a "Personalidade" do Coach de Marketing
        $systemInstruction = "Você é um especialista em Marketing Digital e Copywriting de alta conversão. " .
                             "Sua missão é criar descrições de produtos irresistíveis. " .
                             "Use gatilhos mentais, seja persuasivo, mas mantenha um tom profissional.";

        // Monta o JSON para a API do Google
        $body = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $systemInstruction . "\n\n" . "Tarefa: " . $prompt]
                    ]
                ]
            ]
        ];

        try { $apiKey = $_ENV['GEMINI_API_KEY'];
            
            // ALTERAÇÃO: Mudamos de 'gemini-1.5-flash' para 'gemini-1.5-flash-001'
            // Às vezes a versão "curta" não funciona em todas as contas/regiões na v1beta
            $model = 'gemini-2.0-flash'; 

            $res = $client->post("https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$apiKey}", [
                'json' => $body,
                'headers' => ['Content-Type' => 'application/json']
            ]);

            $result = json_decode($resultBody = $res->getBody(), true);
            
            // Extrai o texto da resposta complexa do Google
            $generatedText = $result['candidates'][0]['content']['parts'][0]['text'] ?? 'Erro ao gerar texto.';

            $response->getBody()->write(json_encode([
                'status' => 'success',
                'data' => $generatedText
            ]));

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode([
                'error' => 'Falha na comunicação com a IA',
                'details' => $e->getMessage()
            ]));
            return $response->withStatus(500);
        }

        return $response->withHeader('Content-Type', 'application/json');
    }
}