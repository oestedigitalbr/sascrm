<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Product;
use Ramsey\Uuid\Uuid;
use Slim\Psr7\UploadedFile;

class ProductController {

    /**
     * LISTAR (GET)
     */
    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $products = Product::where('user_id', $userToken->sub)->orderBy('created_at', 'desc')->get();
        $response->getBody()->write($products->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    /**
     * CRIAR (POST)
     */
    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $userId = $userToken->sub;
        $data = $request->getParsedBody();
        $uploadedFiles = $request->getUploadedFiles();
        $uploadedImage = $uploadedFiles['image'] ?? null;
        $imageUrl = null;

        // Processamento da Imagem
        if ($uploadedImage && $uploadedImage->getError() === UPLOAD_ERR_OK) {
            $extension = strtolower(pathinfo($uploadedImage->getClientFilename(), PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($extension, $allowed)) {
                $directory = __DIR__ . '/../../public/uploads/' . $userId;
                if (!is_dir($directory)) mkdir($directory, 0755, true);

                $newFilename = Uuid::uuid4()->toString() . '.' . $extension;
                $uploadedImage->moveTo($directory . DIRECTORY_SEPARATOR . $newFilename);
                $imageUrl = '/uploads/' . $userId . '/' . $newFilename;
            }
        }

        // Tratamento de Preço
        $price = isset($data['price']) ? $this->parsePrice($data['price']) : 0.00;

        try {
            $product = Product::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userId,
                'name' => $data['name'],
                'description' => $data['description'] ?? '',
                'sku' => $data['sku'] ?? null,
                'price' => $price,
                'image_url' => $imageUrl
            ]);
            $response->getBody()->write($product->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');
        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500);
        }
    }

    /**
     * ATUALIZAR (POST /products/{id})
     * Usamos POST em vez de PUT por causa do multipart/form-data do PHP
     */
    public function update(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $userId = $userToken->sub;
        $productId = $args['id'];

        $product = Product::where('id', $productId)->where('user_id', $userId)->first();

        if (!$product) {
            $response->getBody()->write(json_encode(['error' => 'Produto não encontrado.']));
            return $response->withStatus(404);
        }

        $data = $request->getParsedBody();
        $uploadedFiles = $request->getUploadedFiles();
        $uploadedImage = $uploadedFiles['image'] ?? null;

        // Atualiza campos de texto
        if (isset($data['name'])) $product->name = $data['name'];
        if (isset($data['description'])) $product->description = $data['description'];
        if (isset($data['sku'])) $product->sku = $data['sku'];
        if (isset($data['price'])) $product->price = $this->parsePrice($data['price']);

        // Atualiza Imagem (Se enviada)
        if ($uploadedImage && $uploadedImage->getError() === UPLOAD_ERR_OK) {
            // 1. Apaga a antiga
            if ($product->image_url) {
                $oldFile = __DIR__ . '/../../public' . $product->image_url;
                if (file_exists($oldFile)) unlink($oldFile);
            }

            // 2. Salva a nova
            $extension = strtolower(pathinfo($uploadedImage->getClientFilename(), PATHINFO_EXTENSION));
            $directory = __DIR__ . '/../../public/uploads/' . $userId;
            if (!is_dir($directory)) mkdir($directory, 0755, true);

            $newFilename = Uuid::uuid4()->toString() . '.' . $extension;
            $uploadedImage->moveTo($directory . DIRECTORY_SEPARATOR . $newFilename);
            $product->image_url = '/uploads/' . $userId . '/' . $newFilename;
        }

        $product->save();
        $response->getBody()->write($product->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    /**
     * DELETAR (DELETE)
     */
    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $userId = $userToken->sub;
        $productId = $args['id'];

        $product = Product::where('id', $productId)->where('user_id', $userId)->first();

        if (!$product) {
            $response->getBody()->write(json_encode(['error' => 'Produto não encontrado.']));
            return $response->withStatus(404);
        }

        // Apaga imagem do disco
        if ($product->image_url) {
            $file = __DIR__ . '/../../public' . $product->image_url;
            if (file_exists($file)) unlink($file);
        }

        $product->delete();
        $response->getBody()->write(json_encode(['message' => 'Deletado com sucesso']));
        return $response->withHeader('Content-Type', 'application/json');
    }

    // Helper para limpar preço
    private function parsePrice($priceStr) {
        $clean = str_replace(['R$', ' ', '.'], '', $priceStr);
        return (float) str_replace(',', '.', $clean);
    }
}