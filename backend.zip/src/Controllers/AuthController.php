<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\User;
use Firebase\JWT\JWT;
use Ramsey\Uuid\Uuid;

class AuthController {
    
    // Rota: POST /auth/register (Apenas para criar o primeiro admin)
    public function register(Request $request, Response $response) {
        $data = $request->getParsedBody();
        
        // Verifica se email já existe
        if (User::where('email', $data['email'])->exists()) {
             $response->getBody()->write(json_encode(['error' => 'Email já cadastrado']));
             return $response->withStatus(400);
        }

        $user = User::create([
            'id' => Uuid::uuid4()->toString(),
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => password_hash($data['password'], PASSWORD_BCRYPT),
            'role' => 'owner', // O primeiro é sempre dono
            'plan_config' => json_encode(['crm' => true, 'ai' => true])
        ]);

        $response->getBody()->write(json_encode(['message' => 'Usuário criado!', 'id' => $user->id]));
        return $response->withHeader('Content-Type', 'application/json');
    }

    // Rota: POST /auth/login
    public function login(Request $request, Response $response) {
        $data = $request->getParsedBody();
        $user = User::where('email', $data['email'])->first();

        if (!$user || !password_verify($data['password'], $user->password)) {
            $response->getBody()->write(json_encode(['error' => 'Credenciais inválidas']));
            return $response->withStatus(401);
        }

        // Payload do Token
        $payload = [
            'sub' => $user->id,
            'email' => $user->email,
            'role' => $user->role,
            'iat' => time(),
            'exp' => time() + (60 * 60 * 24) // Expira em 24h
        ];

        $jwt = JWT::encode($payload, $_ENV['JWT_SECRET'], 'HS256');

        $response->getBody()->write(json_encode([
            'token' => $jwt,
            'user' => [
                'id' => $user->id,
                'name' => $user->name,
                'role' => $user->role
            ]
        ]));
        
        return $response->withHeader('Content-Type', 'application/json');
    }
}