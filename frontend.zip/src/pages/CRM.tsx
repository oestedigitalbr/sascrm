import { useEffect, useState } from 'react';
import { DragDropContext, Droppable, Draggable } from '@hello-pangea/dnd';
import type { DropResult } from '@hello-pangea/dnd';
import Layout from '../components/Layout';
import api from '../services/api';
import LeadDetailsModal from '../components/LeadDetailsModal';
import CreateLeadModal from '../components/CreateLeadModal'; // <--- IMPORT DO NOVO MODAL
import { 
  Users, DollarSign, ArrowRight, Phone, Calendar, 
  Search, Filter, Plus, Bot, User 
} from 'lucide-react';

interface Lead {
  id: string;
  name: string;
  phone: string;
  email: string;
  status: string;
  value?: number;
  agent_paused: boolean;
  follow_up_date?: string;
  pipeline: 'agent' | 'client';
}

interface Column {
  id: string;
  title: string;
  color: string;
}

// --- CONFIGURAÇÃO DAS COLUNAS ---

// Pipeline do Robô (Triagem e Agendamento)
const AGENT_COLUMNS: Column[] = [
  { id: 'triage', title: 'Triagem (Entrada)', color: 'border-slate-500' },
  { id: 'qualifying', title: 'Em Qualificação', color: 'border-blue-500' },
  { id: 'scheduled', title: 'Agendado/Quente', color: 'border-purple-500' },
  { id: 'handover', title: 'Enviar p/ Comercial ➔', color: 'border-emerald-500 bg-emerald-900/10' }, // Coluna de Transferência
];

// Pipeline do Vendedor (Fechamento)
const CLIENT_COLUMNS: Column[] = [
  { id: 'new', title: 'Novos Leads', color: 'border-blue-500' },
  { id: 'contacted', title: 'Em Contato', color: 'border-yellow-500' },
  { id: 'proposal', title: 'Proposta Enviada', color: 'border-purple-500' },
  { id: 'negotiation', title: 'Em Negociação', color: 'border-orange-500' },
  { id: 'closed', title: 'Fechado / Ganho', color: 'border-emerald-500' },
  { id: 'lost', title: 'Perdido', color: 'border-red-500' },
];

export default function CRM() {
  const [activePipeline, setActivePipeline] = useState<'agent' | 'client'>('client');
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Controle dos Modais
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null); // Modal de Detalhes
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);   // Modal de Criar Lead

  // Carrega leads com filtro de Pipeline e proteção de Array
  async function loadLeads() {
    setLoading(true);
    try {
      const response = await api.get(`/api/crm/board?pipeline=${activePipeline}`);
      if (Array.isArray(response.data)) {
        setLeads(response.data);
      } else {
        console.warn("API não retornou array:", response.data);
        setLeads([]);
      }
    } catch (error) {
      console.error("Erro ao carregar leads", error);
      setLeads([]);
    } finally {
      setLoading(false);
    }
  }

  // Recarrega sempre que mudar a aba (Pipeline)
  useEffect(() => { loadLeads(); }, [activePipeline]);

  // Lógica de Arrastar e Soltar (Drag & Drop)
  async function onDragEnd(result: DropResult) {
    if (!result.destination) return;
    const { source, destination, draggableId } = result;
    if (source.droppableId === destination.droppableId) return;

    // --- TRANSFERÊNCIA DE PIPELINE (IA -> HUMANO) ---
    if (activePipeline === 'agent' && destination.droppableId === 'handover') {
        const confirmTransfer = confirm("Transferir este lead para o CRM Comercial?");
        if (!confirmTransfer) {
            loadLeads(); // Cancela visualmente
            return;
        }

        try {
            // Remove da tela atual (Otimista)
            setLeads(leads.filter(l => l.id !== draggableId));
            
            // API: Muda status para 'new' e pipeline para 'client'
            await api.put(`/api/crm/leads/${draggableId}/move`, { 
                status: 'new', 
                pipeline: 'client' 
            });
            alert("Lead enviado para o Comercial com sucesso!");
        } catch (error) {
            alert("Erro ao transferir lead");
            loadLeads();
        }
        return;
    }

    // --- MOVIMENTO NORMAL (Dentro do mesmo quadro) ---
    const updatedLeads = leads.map(lead => 
      lead.id === draggableId ? { ...lead, status: destination.droppableId } : lead
    );
    setLeads(updatedLeads);

    try {
      await api.put(`/api/crm/leads/${draggableId}/move`, { status: destination.droppableId });
    } catch (error) {
      console.error("Erro ao mover card", error);
      loadLeads(); // Reverte
    }
  }

  // Define quais colunas renderizar
  const currentColumns = activePipeline === 'agent' ? AGENT_COLUMNS : CLIENT_COLUMNS;

  return (
    <Layout title="Gestão de Leads (CRM)">
      <div className="flex flex-col h-full">
        
        {/* --- HEADER E FILTROS --- */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
            
            {/* Abas de Pipeline */}
            <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800">
                <button 
                    onClick={() => setActivePipeline('agent')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition ${activePipeline === 'agent' ? 'bg-purple-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    <Bot size={18}/> CRM Agente (IA)
                </button>
                <button 
                    onClick={() => setActivePipeline('client')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold flex items-center gap-2 transition ${activePipeline === 'client' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
                >
                    <User size={18}/> CRM Comercial
                </button>
            </div>

            {/* Ações e Busca */}
            <div className="flex gap-3">
                <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg px-3 py-2 w-64 focus-within:border-blue-600 transition">
                    <Search size={18} className="text-slate-500 mr-2"/>
                    <input type="text" placeholder="Filtrar leads..." className="bg-transparent outline-none text-sm text-white w-full placeholder-slate-600"/>
                </div>
                
                <button className="flex items-center gap-2 px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-slate-300 hover:text-white hover:border-slate-700 transition text-sm">
                    <Filter size={16}/>
                </button>

                {/* Botão de Adicionar Lead (Abre Modal) */}
                <button 
                    onClick={() => setIsCreateModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-sm shadow-lg shadow-emerald-900/20 transition"
                >
                    <Plus size={18}/> Add Lead
                </button>
            </div>
        </div>

        {/* --- BOARD KANBAN --- */}
        <DragDropContext onDragEnd={onDragEnd}>
          <div className="flex gap-4 overflow-x-auto pb-4 h-full snap-x">
            {currentColumns.map(col => (
              <Droppable key={col.id} droppableId={col.id}>
                {(provided, snapshot) => (
                  <div
                    ref={provided.innerRef}
                    {...provided.droppableProps}
                    className={`flex-shrink-0 w-80 bg-slate-900/50 rounded-xl border-t-4 ${col.color} flex flex-col h-full max-h-[calc(100vh-240px)] snap-center transition-colors ${col.id === 'handover' ? 'border-dashed border-2 bg-emerald-900/5' : ''}`}
                  >
                    {/* Cabeçalho da Coluna */}
                    <div className="p-4 border-b border-slate-800 bg-slate-900/80 rounded-t-lg backdrop-blur-sm sticky top-0 z-10 flex justify-between items-center">
                        <h3 className="font-bold text-slate-200">{col.title}</h3>
                        <span className="bg-slate-800 text-slate-400 text-xs px-2 py-1 rounded-full">
                            {Array.isArray(leads) ? leads.filter(l => l.status === col.id).length : 0}
                        </span>
                    </div>

                    {/* Lista de Cards */}
                    <div className={`p-3 flex-1 overflow-y-auto space-y-3 scrollbar-thin scrollbar-thumb-slate-800 ${snapshot.isDraggingOver ? 'bg-slate-800/20' : ''}`}>
                        {Array.isArray(leads) && leads
                            .filter(l => l.status === col.id)
                            .map((lead, index) => (
                            <Draggable key={lead.id} draggableId={lead.id} index={index}>
                                {(provided, snapshot) => (
                                    <div
                                        ref={provided.innerRef}
                                        {...provided.draggableProps}
                                        {...provided.dragHandleProps}
                                        onClick={() => setSelectedLead(lead)} // Abre detalhes ao clicar
                                        className={`bg-slate-950 p-4 rounded-lg border border-slate-800 shadow-sm hover:border-blue-500/50 cursor-pointer group transition-all relative ${snapshot.isDragging ? 'rotate-2 scale-105 shadow-2xl z-50 border-blue-500' : ''}`}
                                    >
                                        <div className="flex justify-between items-start mb-2">
                                            <span className="font-bold text-white group-hover:text-blue-400 transition truncate">{lead.name}</span>
                                            {lead.agent_paused && (
                                                <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="Atendimento Humano Ativo"></span>
                                            )}
                                        </div>
                                        
                                        <div className="space-y-1 mb-3">
                                            <div className="flex items-center text-xs text-slate-500">
                                                <Phone size={12} className="mr-2"/> {lead.phone}
                                            </div>
                                            {lead.value && (
                                                <div className="flex items-center text-xs text-emerald-500 font-medium">
                                                    <DollarSign size={12} className="mr-2"/> R$ {lead.value}
                                                </div>
                                            )}
                                        </div>

                                        <div className="flex justify-between items-center pt-3 border-t border-slate-900">
                                            <span className="text-[10px] text-slate-600 uppercase font-bold tracking-wider">
                                                {lead.follow_up_date ? '📅 Follow-up' : 'Sem agendamento'}
                                            </span>
                                            <div className="bg-slate-900 p-1.5 rounded text-slate-500 hover:text-white hover:bg-blue-600 transition">
                                                <ArrowRight size={14}/>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </Draggable>
                        ))}
                        {provided.placeholder}
                        
                        {/* Dica visual na coluna de transferência */}
                        {col.id === 'handover' && Array.isArray(leads) && leads.filter(l => l.status === col.id).length === 0 && (
                            <div className="text-center text-slate-600 text-xs mt-4 italic border border-dashed border-slate-700 p-4 rounded select-none">
                                Arraste aqui para enviar ao Comercial
                            </div>
                        )}
                    </div>
                  </div>
                )}
              </Droppable>
            ))}
          </div>
        </DragDropContext>

        {/* --- MODAIS --- */}
        
        {/* Modal de Detalhes (Agenda, Chat, Info) */}
        {selectedLead && (
            <LeadDetailsModal 
                isOpen={!!selectedLead} 
                onClose={() => setSelectedLead(null)} 
                lead={selectedLead}
                onUpdate={loadLeads}
            />
        )}

        {/* Modal de Criação de Lead */}
        <CreateLeadModal
            isOpen={isCreateModalOpen}
            onClose={() => setIsCreateModalOpen(false)}
            onSuccess={loadLeads}
            activePipeline={activePipeline} // Passa o pipeline atual para saber onde criar
        />

      </div>
    </Layout>
  );
}