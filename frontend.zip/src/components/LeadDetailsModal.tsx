import { useState, useEffect, useRef } from 'react';
import { 
    X, MessageSquare, Calendar, User, Send, Power, Clock, Save, 
    Trash2, CheckCircle, AlertCircle, Bot, Edit 
} from 'lucide-react';
import api from '../services/api';

interface Lead {
  id: string;
  name: string;
  phone: string;
  email?: string;
  status: string;
  agent_paused: boolean;
  follow_up_date?: string;
  follow_up_notes?: string;
}

interface Message {
    id: string;
    sender_type: 'ai' | 'human' | 'lead';
    content: string;
    created_at: string;
}

interface Appointment {
    id: string;
    title: string;
    start_time: string;
    status: string;
}

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  lead: Lead;
  onUpdate: () => void;
}

export default function LeadDetailsModal({ isOpen, onClose, lead, onUpdate }: ModalProps) {
  const [activeTab, setActiveTab] = useState<'info' | 'chat' | 'agenda'>('info');
  const [localLead, setLocalLead] = useState<Lead>(lead);
  const [isLoading, setIsLoading] = useState(false);
  
  // Refs para focar nos inputs ao clicar em Editar
  const dateInputRef = useRef<HTMLInputElement>(null);

  // Follow-up States
  const [followDate, setFollowDate] = useState('');
  const [followNote, setFollowNote] = useState('');

  // Chat States
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');

  // Agenda States
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [newAptTitle, setNewAptTitle] = useState('');
  const [newAptDate, setNewAptDate] = useState('');

  useEffect(() => {
    if (isOpen) {
        setLocalLead(lead);
        // Preenche os campos com o valor atual do banco
        setFollowDate(lead.follow_up_date ? new Date(lead.follow_up_date).toISOString().slice(0, 16) : '');
        setFollowNote(lead.follow_up_notes || '');
        
        loadAppointments();
        
        // MOCK MENSAGENS
        setMessages([
            { id: '1', sender_type: 'ai', content: `Olá ${lead.name}, sou a IA da AgenteUP4.`, created_at: 'Ontem' },
            { id: '2', sender_type: 'lead', content: 'Gostaria de um orçamento.', created_at: 'Ontem' },
        ]);
    }
  }, [isOpen, lead]);

  async function loadAppointments() {
      try {
          const res = await api.get('/api/agenda'); 
          const myApts = res.data.filter((a: any) => a.lead_id === lead.id);
          setAppointments(myApts);
      } catch (error) { console.error('Erro agenda', error); }
  }

  // --- FUNÇÕES DE FOLLOW-UP ---

  async function handleSaveFollowUp() {
      setIsLoading(true);
      try {
          await api.put(`/api/crm/leads/${lead.id}`, {
              follow_up_date: followDate || null,
              follow_up_notes: followNote
          });
          
          // Atualiza visualmente
          setLocalLead({ 
              ...localLead, 
              follow_up_date: followDate, 
              follow_up_notes: followNote 
          });
          
          alert('Follow-up definido com sucesso!');
          onUpdate(); 
      } catch (error) {
          alert('Erro ao salvar follow-up');
      } finally { setIsLoading(false); }
  }

  async function handleDeleteFollowUp() {
      if(!confirm("Tem certeza que deseja remover este lembrete de Follow-up?")) return;
      
      setIsLoading(true);
      try {
          // Envia NULL para limpar no banco
          await api.put(`/api/crm/leads/${lead.id}`, {
              follow_up_date: null,
              follow_up_notes: null
          });

          // Limpa visualmente
          setLocalLead({ 
              ...localLead, 
              follow_up_date: undefined, 
              follow_up_notes: undefined 
          });
          setFollowDate('');
          setFollowNote('');

          alert('Follow-up removido!');
          onUpdate();
      } catch (error) {
          alert('Erro ao remover follow-up');
      } finally { setIsLoading(false); }
  }

  function handleEditFollowUp() {
      // Joga os valores salvos para os inputs (caso tenha mudado) e foca
      setFollowDate(localLead.follow_up_date ? new Date(localLead.follow_up_date).toISOString().slice(0, 16) : '');
      setFollowNote(localLead.follow_up_notes || '');
      dateInputRef.current?.focus();
  }

  // --- OUTRAS FUNÇÕES ---

  async function toggleAgentPause() {
      try {
          const newState = !localLead.agent_paused;
          setLocalLead({ ...localLead, agent_paused: newState });
          await api.put(`/api/crm/leads/${lead.id}`, { agent_paused: newState });
          onUpdate();
      } catch (error) { alert('Erro ao mudar status do agente'); }
  }

  async function handleAddAppointment() {
      if(!newAptTitle || !newAptDate) return alert('Preencha título e data');
      try {
          await api.post('/api/agenda', {
              lead_id: lead.id,
              title: newAptTitle,
              start_time: newAptDate,
              observations: ''
          });
          alert('Reunião agendada!');
          setNewAptTitle(''); setNewAptDate('');
          loadAppointments();
      } catch (error: any) { 
          const msg = error.response?.data?.error || error.response?.data?.details || 'Erro ao agendar';
          alert(msg); 
      }
  }

  async function handleSendMessage() {
      if(!newMessage.trim()) return;
      setMessages([...messages, { id: Math.random().toString(), sender_type: 'human', content: newMessage, created_at: 'Agora' }]);
      setNewMessage('');
  }

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-slate-900 border border-slate-700 w-full max-w-5xl h-[90vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-scale-up">
        
        {/* HEADER */}
        <div className="p-4 border-b border-slate-800 flex justify-between items-center bg-slate-950">
            <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-indigo-600 flex items-center justify-center font-bold text-white text-xl shadow-lg">
                    {localLead.name[0]}
                </div>
                <div>
                    <h3 className="text-xl font-bold text-white tracking-tight">{localLead.name}</h3>
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                        <span>{localLead.phone}</span>
                        {localLead.email && <span className="text-slate-600">• {localLead.email}</span>}
                    </div>
                </div>
            </div>
            <div className="flex items-center gap-3">
                <button 
                    onClick={toggleAgentPause}
                    className={`px-4 py-2 rounded-lg text-xs font-bold border flex items-center gap-2 transition ${localLead.agent_paused ? 'bg-amber-500/10 border-amber-500 text-amber-500 hover:bg-amber-500/20' : 'bg-emerald-500/10 border-emerald-500 text-emerald-500 hover:bg-emerald-500/20'}`}
                >
                    <Power size={16} /> {localLead.agent_paused ? 'PAUSADO (Humano)' : 'ATIVO (Automático)'}
                </button>
                <button onClick={onClose} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition"><X size={24}/></button>
            </div>
        </div>

        {/* CORPO */}
        <div className="flex flex-1 overflow-hidden">
            
            {/* SIDEBAR ABAS */}
            <div className="w-16 md:w-64 bg-slate-950 border-r border-slate-800 flex flex-col p-3 gap-2">
                <button onClick={() => setActiveTab('info')} className={`p-3 rounded-xl flex items-center gap-3 transition text-sm font-medium ${activeTab === 'info' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-900 hover:text-white'}`}>
                    <User size={20}/> <span className="hidden md:block">Dados & Follow-up</span>
                </button>
                <button onClick={() => setActiveTab('chat')} className={`p-3 rounded-xl flex items-center gap-3 transition text-sm font-medium ${activeTab === 'chat' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-900 hover:text-white'}`}>
                    <MessageSquare size={20}/> <span className="hidden md:block">Chat Ao Vivo</span>
                </button>
                <button onClick={() => setActiveTab('agenda')} className={`p-3 rounded-xl flex items-center gap-3 transition text-sm font-medium ${activeTab === 'agenda' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-900 hover:text-white'}`}>
                    <Calendar size={20}/> <span className="hidden md:block">Agenda & Reuniões</span>
                </button>
            </div>

            {/* CONTEÚDO */}
            <div className="flex-1 overflow-y-auto bg-slate-900 p-8">
                
                {/* === ABA 1: DADOS E FOLLOW-UP === */}
                {activeTab === 'info' && (
                    <div className="space-y-8 max-w-3xl mx-auto">
                        
                        {/* Seção de Follow-up (Edição/Criação) */}
                        <div className="bg-slate-800/40 p-6 rounded-2xl border border-slate-700/50">
                            <h4 className="text-white font-bold mb-6 flex items-center gap-2 text-lg">
                                <Clock size={20} className="text-orange-400"/> Definir Próximo Passo (Follow-up)
                            </h4>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                                <div>
                                    <label className="text-xs text-slate-400 block mb-1.5 font-medium uppercase tracking-wider">Data do Retorno</label>
                                    <input 
                                        ref={dateInputRef} // REF para focar aqui
                                        type="datetime-local" 
                                        className="w-full bg-slate-950 border border-slate-600 rounded-xl p-3 text-white text-sm outline-none focus:border-blue-500 transition shadow-inner"
                                        value={followDate}
                                        onChange={e => setFollowDate(e.target.value)}
                                    />
                                </div>
                                <div className="md:col-span-2">
                                    <label className="text-xs text-slate-400 block mb-1.5 font-medium uppercase tracking-wider">Nota Interna</label>
                                    <input 
                                        type="text" 
                                        placeholder="Ex: Cliente pediu para ligar após às 14h..." 
                                        className="w-full bg-slate-950 border border-slate-600 rounded-xl p-3 text-white text-sm outline-none focus:border-blue-500 transition shadow-inner"
                                        value={followNote}
                                        onChange={e => setFollowNote(e.target.value)}
                                    />
                                </div>
                            </div>
                            <button 
                                onClick={handleSaveFollowUp} 
                                disabled={isLoading}
                                className="mt-6 w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white py-3 rounded-xl text-sm font-bold transition flex justify-center gap-2 shadow-lg shadow-blue-900/20"
                            >
                                {isLoading ? 'Salvando...' : <><Save size={18}/> Salvar Follow-up</>}
                            </button>
                        </div>

                        {/* VISUALIZADOR DE STATUS ATUAL + AÇÕES DE EXCLUIR/EDITAR */}
                        {localLead.follow_up_date && (
                            <div className="bg-emerald-500/10 border border-emerald-500/20 p-4 rounded-xl flex justify-between items-start animate-fade-in-up">
                                <div className="flex items-start gap-4">
                                    <CheckCircle className="text-emerald-400 shrink-0 mt-1" size={24}/>
                                    <div>
                                        <h5 className="text-emerald-400 font-bold text-sm">Follow-up Agendado</h5>
                                        <p className="text-white text-lg font-medium mt-1">
                                            {new Date(localLead.follow_up_date).toLocaleString('pt-BR', { dateStyle: 'long', timeStyle: 'short' })}
                                        </p>
                                        {localLead.follow_up_notes && (
                                            <p className="text-emerald-200/70 text-sm mt-1 italic">"{localLead.follow_up_notes}"</p>
                                        )}
                                    </div>
                                </div>
                                
                                {/* NOVOS BOTÕES DE AÇÃO */}
                                <div className="flex gap-2">
                                    <button 
                                        onClick={handleEditFollowUp}
                                        className="p-2 bg-slate-900 hover:bg-blue-600 text-blue-400 hover:text-white rounded-lg transition border border-slate-700 hover:border-blue-500"
                                        title="Editar (Preencher formulário acima)"
                                    >
                                        <Edit size={18}/>
                                    </button>
                                    <button 
                                        onClick={handleDeleteFollowUp}
                                        className="p-2 bg-slate-900 hover:bg-red-600 text-red-400 hover:text-white rounded-lg transition border border-slate-700 hover:border-red-500"
                                        title="Excluir Follow-up"
                                    >
                                        <Trash2 size={18}/>
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Dados Cadastrais */}
                        <div className="bg-slate-800/40 p-6 rounded-2xl border border-slate-700/50 opacity-75 hover:opacity-100 transition">
                            <h4 className="text-white font-bold mb-4 flex items-center gap-2"><User size={18} className="text-slate-400"/> Dados Cadastrais</h4>
                            <div className="grid grid-cols-2 gap-4">
                                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                                    <label className="text-[10px] text-slate-500 uppercase font-bold">Nome</label>
                                    <p className="text-slate-300 text-sm truncate">{localLead.name}</p>
                                </div>
                                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800">
                                    <label className="text-[10px] text-slate-500 uppercase font-bold">Telefone</label>
                                    <p className="text-slate-300 text-sm truncate">{localLead.phone}</p>
                                </div>
                                {localLead.email && (
                                    <div className="col-span-2 p-3 bg-slate-950 rounded-lg border border-slate-800">
                                        <label className="text-[10px] text-slate-500 uppercase font-bold">Email</label>
                                        <p className="text-slate-300 text-sm truncate">{localLead.email}</p>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {/* ABA 2 (Chat) e ABA 3 (Agenda) continuam iguais... */}
                {activeTab === 'chat' && (
                    <div className="flex flex-col h-full bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-inner">
                        <div className="flex-1 overflow-y-auto p-6 space-y-6">
                            {messages.map((msg) => (
                                <div key={msg.id} className={`flex flex-col ${msg.sender_type === 'lead' ? 'items-start' : 'items-end'}`}>
                                    <div className={`max-w-[80%] p-4 rounded-2xl text-sm leading-relaxed shadow-md ${
                                        msg.sender_type === 'lead' ? 'bg-slate-800 text-slate-200 rounded-tl-none' : 
                                        msg.sender_type === 'ai' ? 'bg-purple-900/30 border border-purple-500/20 text-purple-100 rounded-tr-none' :
                                        'bg-blue-600 text-white rounded-tr-none'
                                    }`}>
                                        {msg.sender_type === 'ai' && <span className="text-[10px] uppercase font-bold text-purple-400 block mb-1 tracking-wider flex items-center gap-1"><Bot size={10}/> IA Agente</span>}
                                        {msg.content}
                                    </div>
                                    <span className="text-[10px] text-slate-600 mt-1.5 px-1">{msg.created_at}</span>
                                </div>
                            ))}
                        </div>
                        <div className="p-4 bg-slate-900 border-t border-slate-800 flex gap-3 items-center">
                            <input 
                                type="text" 
                                placeholder="Digite sua mensagem..." 
                                className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-blue-500 transition shadow-inner"
                                value={newMessage}
                                onChange={e => setNewMessage(e.target.value)}
                                onKeyDown={e => e.key === 'Enter' && handleSendMessage()}
                            />
                            <button onClick={handleSendMessage} className="bg-blue-600 hover:bg-blue-500 p-3 rounded-xl text-white transition shadow-lg shadow-blue-900/20"><Send size={20}/></button>
                        </div>
                    </div>
                )}

                {activeTab === 'agenda' && (
                    <div className="space-y-8 max-w-4xl mx-auto animate-fade-in-up">
                        <div className="bg-slate-800/40 p-6 rounded-2xl border border-slate-700/50">
                            <h4 className="text-white font-bold mb-6 flex items-center gap-2 text-lg"><Calendar size={20} className="text-emerald-400"/> Novo Agendamento</h4>
                            <div className="flex flex-col md:flex-row gap-4">
                                <input 
                                    type="text" 
                                    placeholder="Título (Ex: Reunião de Apresentação)" 
                                    className="flex-[2] bg-slate-950 border border-slate-600 rounded-xl p-3 text-white text-sm outline-none focus:border-emerald-500 transition"
                                    value={newAptTitle}
                                    onChange={e => setNewAptTitle(e.target.value)}
                                />
                                <input 
                                    type="datetime-local" 
                                    className="flex-1 bg-slate-950 border border-slate-600 rounded-xl p-3 text-white text-sm outline-none focus:border-emerald-500 transition"
                                    value={newAptDate}
                                    onChange={e => setNewAptDate(e.target.value)}
                                />
                                <button onClick={handleAddAppointment} className="bg-emerald-600 hover:bg-emerald-500 text-white px-8 py-3 rounded-xl font-bold text-sm shadow-lg shadow-emerald-900/20 transition">Agendar</button>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h4 className="text-slate-400 text-xs font-bold uppercase tracking-widest mb-2 px-1">Eventos Agendados</h4>
                            {appointments.length === 0 ? (
                                <div className="text-center py-12 border border-dashed border-slate-800 rounded-2xl bg-slate-900/50">
                                    <Calendar size={48} className="mx-auto text-slate-700 mb-3"/>
                                    <p className="text-slate-500">Nenhum agendamento futuro.</p>
                                </div>
                            ) : appointments.map(apt => (
                                <div key={apt.id} className="bg-slate-950 border border-slate-800 p-5 rounded-2xl flex justify-between items-center hover:border-slate-700 transition group hover:shadow-lg">
                                    <div className="flex items-center gap-5">
                                        <div className="bg-slate-800 p-3 rounded-xl text-slate-400 group-hover:text-emerald-400 group-hover:bg-emerald-500/10 transition">
                                            <Calendar size={24}/>
                                        </div>
                                        <div>
                                            <p className="font-bold text-white text-lg">{apt.title}</p>
                                            <p className="text-sm text-slate-400 flex items-center gap-2">
                                                {new Date(apt.start_time).toLocaleString('pt-BR', { dateStyle: 'full', timeStyle: 'short' })}
                                            </p>
                                        </div>
                                    </div>
                                    <span className="px-4 py-1.5 bg-slate-900 border border-slate-800 text-xs rounded-full text-emerald-400 font-bold uppercase tracking-wider">{apt.status}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

            </div>
        </div>
      </div>
    </div>
  );
}