<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Lead;
use Ramsey\Uuid\Uuid;

class CRMController {

    /**
     * LISTAR LEADS (Filtrado por Pipeline)
     * GET /api/crm/board?pipeline=agent|client
     */
    public function index(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $params = $request->getQueryParams();
        
        // Se não informar, assume 'client' (Comercial)
        $pipeline = $params['pipeline'] ?? 'client';

        $leads = Lead::where('user_id', $userToken->sub)
                     ->where('pipeline', $pipeline)
                     ->orderBy('created_at', 'desc')
                     ->get();
        
        $response->getBody()->write($leads->toJson());
        return $response->withHeader('Content-Type', 'application/json');
    }

    /**
     * CRIAR NOVO LEAD
     * POST /api/crm/leads
     */
    public function store(Request $request, Response $response) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();

        // Validação básica
        if (empty($data['name']) || empty($data['phone'])) {
            $response->getBody()->write(json_encode(['error' => 'Nome e Telefone são obrigatórios']));
            return $response->withStatus(400);
        }

        try {
            $lead = Lead::create([
                'id' => Uuid::uuid4()->toString(),
                'user_id' => $userToken->sub,
                'name' => $data['name'],
                'phone' => $data['phone'],
                'email' => $data['email'] ?? '',
                'value' => $data['value'] ?? 0,
                'status' => $data['status'] ?? 'new', // Status inicial (coluna do Kanban)
                'pipeline' => $data['pipeline'] ?? 'client', // 'agent' ou 'client'
                'agent_paused' => false,
                'follow_up_date' => null,
                'follow_up_notes' => null
            ]);

            $response->getBody()->write($lead->toJson());
            return $response->withStatus(201)->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode([
                'error' => 'Erro ao criar lead',
                'details' => $e->getMessage()
            ]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    /**
     * MOVER CARD (Kanban) OU TRANSFERIR PIPELINE
     * PUT /api/crm/leads/{id}/move
     */
    public function move(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();
        $id = $args['id'];

        $lead = Lead::where('id', $id)->where('user_id', $userToken->sub)->first();

        if (!$lead) {
            return $response->withStatus(404);
        }

        try {
            // Atualiza a Coluna (Status)
            if (isset($data['status'])) {
                $lead->status = $data['status'];
            }
            
            // Atualiza o Pipeline (Transferência IA -> Humano)
            if (isset($data['pipeline'])) {
                $lead->pipeline = $data['pipeline'];
            }

            $lead->save();

            $response->getBody()->write($lead->toJson());
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode(['error' => $e->getMessage()]));
            return $response->withStatus(500);
        }
    }

    /**
     * ATUALIZAR DADOS COMPLETOS (Edição, Follow-up, Pausa Agente)
     * PUT /api/crm/leads/{id}
     */
    public function update(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $data = $request->getParsedBody();
        $id = $args['id'];

        $lead = Lead::where('id', $id)->where('user_id', $userToken->sub)->first();

        if (!$lead) {
            return $response->withStatus(404);
        }

        try {
            // Campos Básicos
            if (isset($data['name'])) $lead->name = $data['name'];
            if (isset($data['phone'])) $lead->phone = $data['phone'];
            if (isset($data['email'])) $lead->email = $data['email'];
            if (isset($data['value'])) $lead->value = $data['value'];
            
            // Follow-up (Tratamento para aceitar NULL)
            if (array_key_exists('follow_up_date', $data)) {
                $lead->follow_up_date = !empty($data['follow_up_date']) ? $data['follow_up_date'] : null;
            }
            if (array_key_exists('follow_up_notes', $data)) {
                $lead->follow_up_notes = $data['follow_up_notes'];
            }

            // Controle do Agente (Pausar/Ativar)
            if (isset($data['agent_paused'])) {
                $lead->agent_paused = filter_var($data['agent_paused'], FILTER_VALIDATE_BOOLEAN);
            }

            $lead->save();

            $response->getBody()->write($lead->toJson());
            return $response->withHeader('Content-Type', 'application/json');

        } catch (\Exception $e) {
            $response->getBody()->write(json_encode([
                'error' => 'Erro ao atualizar lead',
                'details' => $e->getMessage()
            ]));
            return $response->withStatus(500)->withHeader('Content-Type', 'application/json');
        }
    }

    /**
     * EXCLUIR LEAD
     * DELETE /api/crm/leads/{id}
     */
    public function destroy(Request $request, Response $response, array $args) {
        $userToken = $request->getAttribute('user');
        $lead = Lead::where('id', $args['id'])->where('user_id', $userToken->sub)->first();

        if ($lead) {
            $lead->delete();
            $response->getBody()->write(json_encode(['message' => 'Lead removido com sucesso']));
        } else {
            return $response->withStatus(404);
        }
        return $response->withHeader('Content-Type', 'application/json');
    }
}